import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:url_launcher/url_launcher.dart';

const aipBlue = Color(0xFF318BFF);
const aipCyan = Color(0xFF68DDF5);
const aipNavy = Color(0xFF081321);
const aipPanel = Color(0xFF12243A);

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  // Configure these values after creating your Supabase project.
  const supabaseUrl = String.fromEnvironment('SUPABASE_URL');
  const supabaseAnonKey = String.fromEnvironment('SUPABASE_ANON_KEY');
  if (supabaseUrl.isNotEmpty && supabaseAnonKey.isNotEmpty) {
    await Supabase.initialize(url: supabaseUrl, anonKey: supabaseAnonKey);
  }
  runApp(const AipApp());
}

class AipApp extends StatelessWidget {
  const AipApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'AIP | العميسي للإنتاج المبكر', debugShowCheckedModeBanner: false,
    theme: ThemeData(useMaterial3: true, brightness: Brightness.dark,
      scaffoldBackgroundColor: aipNavy, colorScheme: ColorScheme.fromSeed(seedColor: aipBlue, brightness: Brightness.dark),
      fontFamily: 'Roboto', cardTheme: CardThemeData(color: aipPanel, elevation: 0, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)))),
    home: const HomePage(),
  );
}

class ServiceItem {
  final String category, title, description, details;
  final IconData icon;
  const ServiceItem(this.category, this.title, this.description, this.details, this.icon);
}

const serviceItems = <ServiceItem>[
  ServiceItem('التصميم والإعلانات','إعلانات المحلات والشركات','إعلان احترافي يعرّف الجمهور بنشاطك وخدماتك.','نرتب اسم النشاط والخدمات والمميزات والموقع وبيانات التواصل في تصميم واضح ومتناسق مع طبيعة علامتك التجارية. مناسب للمحلات والشركات والمكاتب والمشاريع الناشئة.',Icons.storefront),
  ServiceItem('التصميم والإعلانات','إعلانات المنتجات والعروض والتخفيضات','إبراز المنتج والسعر والعرض بصورة جذابة.','إظهار المنتج ومميزاته والسعر ونسبة الخصم ومدة العرض ووسائل التواصل ضمن تصميم تسويقي يساعد العميل على فهم العرض بسرعة.',Icons.sell),
  ServiceItem('التصميم والإعلانات','تصميم الشعارات','شعار يعبر عن فكرة مشروعك وشخصيته.','ابتكار تصور بصري للشعار يراعي طبيعة النشاط والجمهور، مع الاهتمام بالوضوح وسهولة الاستخدام في الإعلانات والملفات الرقمية.',Icons.auto_awesome),
  ServiceItem('التصميم والإعلانات','الهويات البصرية','مظهر متناسق يجعل علامتك سهلة التمييز.','اختيار لوحة الألوان والخطوط والأسلوب البصري وقواعد استخدام الشعار لتظهر علامتك بصورة موحدة عبر المواد التسويقية.',Icons.palette),
  ServiceItem('التصميم والإعلانات','بطاقات الأعمال والمنشورات','بطاقات ومنشورات منظمة للطباعة والمشاركة.','تصميم بطاقات الأعمال والمنشورات التعريفية مع توزيع الاسم والمسمى والشعار ومعلومات التواصل بشكل أنيق ومقروء.',Icons.badge),
  ServiceItem('التصاميم الدينية','جمعة مباركة','تصاميم أسبوعية بعبارات وأدعية مناسبة.','إعداد تصميم يحمل عبارة جمعة مباركة مع آية أو دعاء أو تذكير، والاهتمام بوضوح النصوص العربية وصحة كتابتها.',Icons.mosque),
  ServiceItem('التصاميم الدينية','الآيات والأذكار والأدعية','تصاميم إيمانية للنشر والمشاركة.','تنسيق الآيات والأذكار والأدعية بخطوط واضحة وخلفيات هادئة. يراجع النص المرسل بعناية، وينبغي التحقق من النص القرآني والحديث قبل النشر.',Icons.menu_book),
  ServiceItem('التصاميم الدينية','خلفيات واتساب والمناسبات الإسلامية','خلفيات دينية بمقاسات مناسبة للهاتف.','تصميم خلفيات للقروبات والحالات والمناسبات الإسلامية مع اختيار الألوان والعبارات والمقاسات المطلوبة.',Icons.phone_android),
  ServiceItem('تصاميم المناسبات','الزواج والخطوبة والتخرج','تهنئة تحمل الاسم والعبارة التي تختارها.','تصميم بطاقات للمناسبات الخاصة مع إضافة الأسماء والتاريخ والعبارات والصور عند الحاجة، وتنسيقها بما يناسب المناسبة.',Icons.celebration),
  ServiceItem('تصاميم المناسبات','عيد المعلم والتهنئة والتكريم','بطاقات شكر وتقدير وتهنئة أنيقة.','تصميم شهادات وبطاقات تهنئة وتكريم، مع إبراز اسم المكرّم والجهة والسبب والتاريخ بأسلوب رسمي أو احتفالي.',Icons.workspace_premium),
  ServiceItem('الفيديو والمونتاج','فيديوهات إعلانية','فيديو يقدم منتجك أو خدمتك بصورة مؤثرة.','إعداد فكرة وتسلسل للمشاهد وإضافة العناوين والصور والصوت والمؤثرات الملائمة لإعلان نشاطك أو منتجك.',Icons.movie),
  ServiceItem('الفيديو والمونتاج','مونتاج الفيديوهات والمؤثرات','تحرير المقاطع وترتيبها وإخراجها.','قص وترتيب اللقطات والانتقالات والعناوين والمؤثرات وضبط الصوت والصورة بما يناسب المنصة ومدة الفيديو المطلوبة.',Icons.video_settings),
  ServiceItem('الفيديو والمونتاج','إضافة الصوت إلى الصور','تحويل الصور إلى مقطع مصحوب بصوت.','إضافة تسجيل أو ملف صوتي إلى صورة واحدة أو عدة صور، مع ضبط مدة العرض والانتقالات وإخراج المقطع بصيغة فيديو.',Icons.music_video),
  ServiceItem('الفيديو والمونتاج','كتابة كلمات الصوت على الصور','عرض الكلمات متزامنة مع الصوت.','إضافة النصوص أو كلمات التسجيل إلى الصور أو الفيديو مع تنسيق الخط واللون وتوقيت ظهور الجمل بحسب المادة المرسلة.',Icons.closed_caption),
  ServiceItem('الأغاني والشيلات','أغانٍ وشيلات حسب الاسم والطلب','محتوى صوتي مخصص وفق تفاصيل المناسبة.','تخصيص الاسم والعبارات والطابع المطلوب، ويمكن للعميل تحديد نوع الشيلة أو أسلوب التهنئة وإرسال الأسماء والتفاصيل اللازمة.',Icons.graphic_eq),
  ServiceItem('الأغاني والشيلات','تهاني صوتية مخصصة','تهنئة صوتية باسم المرسل والمهدى إليه.','إعداد مقدمة مثل «مقدمة من فلان إلى فلان» ثم صياغة تهنئة صوتية تناسب المناسبة، مع تحديد الأسماء ونوع الإلقاء أو الشيلة.',Icons.record_voice_over),
  ServiceItem('الذكاء الاصطناعي','صور إبداعية من وصفك','تحويل الفكرة المكتوبة إلى صورة.','يصف العميل المشهد والألوان والعناصر والأسلوب المرغوب، ثم تُجهز صورة إبداعية وفق التفاصيل والإمكانات المتاحة.',Icons.auto_awesome_motion),
  ServiceItem('الذكاء الاصطناعي','صور شخصية فخمة','معالجة إبداعية للصورة الشخصية.','إضافة خلفية وإضاءة وأجواء بصرية مميزة مع مراعاة الحفاظ على ملامح الشخص الأصلية عندما يكون ذلك مطلوباً.',Icons.portrait),
  ServiceItem('الذكاء الاصطناعي','تحسين وتعديل الصور','تحسين وضوح الصور وتطوير مظهرها.','تقليل التشويش وتحسين الحدة والإضاءة ورفع الدقة قدر الإمكان، أو تنفيذ تعديلات محددة مع الحفاظ على التفاصيل الأصلية.',Icons.high_quality),
  ServiceItem('العروض التقديمية','عروض الشركات والمشاريع','عرض منظم يشرح مشروعك باحتراف.','تنظيم الأفكار إلى شرائح مترابطة تشمل العناوين والنقاط والصور والرسوم التوضيحية عند الحاجة، مع هوية بصرية متناسقة.',Icons.present_to_all),
  ServiceItem('العروض التقديمية','العروض التعليمية والجامعية','شرائح واضحة للشرح والتقديم الأكاديمي.','تنسيق المحتوى التعليمي والجامعي إلى شرائح سهلة القراءة، مع ترتيب المحاور والمراجع والصور حسب متطلبات الجهة التعليمية.',Icons.school),
];

class HomePage extends StatefulWidget { const HomePage({super.key}); @override State<HomePage> createState()=>_HomePageState(); }
class _HomePageState extends State<HomePage> {
  int selectedTab=0;
  @override Widget build(BuildContext context) => Directionality(textDirection: TextDirection.rtl, child: Scaffold(
    appBar: AppBar(backgroundColor:aipNavy, title: Row(children:[Container(padding:const EdgeInsets.symmetric(horizontal:10,vertical:4),decoration:BoxDecoration(gradient:const LinearGradient(colors:[aipBlue,aipCyan]),borderRadius:BorderRadius.circular(9)),child:const Text('AIP',style:TextStyle(color:Colors.black,fontWeight:FontWeight.w900,fontSize:20))),const SizedBox(width:10),const Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text('AIP',style:TextStyle(fontWeight:FontWeight.bold,letterSpacing:2)),Text('العميسي للإنتاج المبكر',style:TextStyle(fontSize:10,color:Colors.white70))])]), actions:[IconButton(onPressed:_whatsapp,icon:const Icon(Icons.chat,color:aipCyan))]),
    body: IndexedStack(index:selectedTab,children:[_home(),_services(),const OrdersPage(),const AccountPage()]),
    bottomNavigationBar:NavigationBar(backgroundColor:aipPanel,indicatorColor:aipBlue.withOpacity(.25),selectedIndex:selectedTab,onDestinationSelected:(i)=>setState(()=>selectedTab=i),destinations:const [NavigationDestination(icon:Icon(Icons.home_outlined),selectedIcon:Icon(Icons.home),label:'الرئيسية'),NavigationDestination(icon:Icon(Icons.grid_view),label:'الخدمات'),NavigationDestination(icon:Icon(Icons.receipt_long),label:'طلباتي'),NavigationDestination(icon:Icon(Icons.person_outline),label:'حسابي')]),
  ));
  Widget _home()=>ListView(padding:const EdgeInsets.all(18),children:[
    Container(padding:const EdgeInsets.all(22),decoration:BoxDecoration(borderRadius:BorderRadius.circular(24),gradient:const LinearGradient(begin:Alignment.topRight,end:Alignment.bottomLeft,colors:[Color(0xFF163C68),Color(0xFF101D30),Color(0xFF0B1727)]),border:Border.all(color:aipBlue.withOpacity(.35))),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[const Text('الإبداع يبدأ بفكرة',style:TextStyle(color:aipCyan)),const SizedBox(height:12),const Text('نحوّل أفكارك\nإلى حضور استثنائي',style:TextStyle(fontSize:29,fontWeight:FontWeight.w900,height:1.45)),const SizedBox(height:10),const Text('حلول التصميم والإعلانات والفيديو والصوت والذكاء الاصطناعي والعروض التقديمية في مكان واحد.',style:TextStyle(color:Colors.white70,height:1.8)),const SizedBox(height:18),FilledButton.icon(onPressed:()=>_openOrder(context),icon:const Icon(Icons.add),label:const Text('اطلب خدمتك الآن'))]),
    const SizedBox(height:25),_sectionTitle('خدماتنا','اكتشف كل ما نقدمه'),...serviceItems.take(6).map((s)=>ServiceCard(item:s,onTap:()=>_detail(context,s))),Align(alignment:Alignment.center,child:TextButton(onPressed:()=>setState(()=>selectedTab=1),child:const Text('عرض جميع الخدمات'))),
    _sectionTitle('من أعمالنا','نماذج وأعمال AIP'),Container(height:125,alignment:Alignment.center,decoration:BoxDecoration(color:aipPanel,borderRadius:BorderRadius.circular(16),border:Border.all(color:Colors.white12)),child:const Text('سيظهر معرض الأعمال بعد إضافة المشاريع من لوحة الإدارة',textAlign:TextAlign.center,style:TextStyle(color:Colors.white60))),
    const SizedBox(height:20),_sectionTitle('تواصل معنا','نحن جاهزون لاستقبال فكرتك'),FilledButton.tonalIcon(onPressed:_whatsapp,icon:const Icon(Icons.chat),label:const Text('تواصل عبر واتساب  782013525')),
  ]);
  Widget _services()=>ListView(padding:const EdgeInsets.all(16),children:[const Text('جميع خدمات AIP',style:TextStyle(fontSize:24,fontWeight:FontWeight.bold)),const SizedBox(height:6),const Text('اختر الخدمة لقراءة شرحها وإرسال طلبك.',style:TextStyle(color:Colors.white60)),const SizedBox(height:15),...serviceItems.map((s)=>ServiceCard(item:s,onTap:()=>_detail(context,s)))]);
  Widget _sectionTitle(String title,String subtitle)=>Padding(padding:const EdgeInsets.only(bottom:12,top:8),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(title,style:const TextStyle(fontSize:21,fontWeight:FontWeight.bold)),Text(subtitle,style:const TextStyle(color:Colors.white60,fontSize:12))]));
  void _detail(BuildContext c,ServiceItem s)=>Navigator.push(c,MaterialPageRoute(builder:(_)=>ServiceDetailPage(item:s)));
  void _openOrder(BuildContext c)=>Navigator.push(c,MaterialPageRoute(builder:(_)=>const OrderFormPage()));
  Future<void> _whatsapp()async{final u=Uri.parse('https://wa.me/967782013525');if(await canLaunchUrl(u))await launchUrl(u,mode:LaunchMode.externalApplication);}
}

class ServiceCard extends StatelessWidget { final ServiceItem item; final VoidCallback onTap; const ServiceCard({super.key,required this.item,required this.onTap}); @override Widget build(BuildContext context)=>Card(child:ListTile(onTap:onTap,leading:CircleAvatar(backgroundColor:aipBlue.withOpacity(.18),child:Icon(item.icon,color:aipCyan)),title:Text(item.title,style:const TextStyle(fontWeight:FontWeight.bold)),subtitle:Text('${item.category} • ${item.description}',maxLines:2,overflow:TextOverflow.ellipsis,style:const TextStyle(color:Colors.white60,fontSize:11)),trailing:const Icon(Icons.chevron_left,color:aipCyan))); }

class ServiceDetailPage extends StatelessWidget { final ServiceItem item; const ServiceDetailPage({super.key,required this.item}); @override Widget build(BuildContext context)=>Directionality(textDirection:TextDirection.rtl,child:Scaffold(appBar:AppBar(title:Text(item.title)),body:ListView(padding:const EdgeInsets.all(20),children:[CircleAvatar(radius:38,backgroundColor:aipBlue.withOpacity(.18),child:Icon(item.icon,size:38,color:aipCyan)),const SizedBox(height:20),Text(item.category,style:const TextStyle(color:aipCyan)),const SizedBox(height:8),Text(item.title,style:const TextStyle(fontSize:27,fontWeight:FontWeight.bold)),const SizedBox(height:12),Text(item.description,style:const TextStyle(fontSize:16,color:Colors.white70)),const SizedBox(height:22),const Text('شرح الخدمة',style:TextStyle(fontSize:19,fontWeight:FontWeight.bold)),const SizedBox(height:8),Text(item.details,style:const TextStyle(height:2,color:Colors.white70)),const SizedBox(height:22),Container(height:150,alignment:Alignment.center,decoration:BoxDecoration(color:aipPanel,borderRadius:BorderRadius.circular(16)),child:const Text('تُعرض هنا نماذج الأعمال المرتبطة بهذه الخدمة',style:TextStyle(color:Colors.white54))),const SizedBox(height:22),FilledButton.icon(onPressed:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>OrderFormPage(service:item.title))),icon:const Icon(Icons.send),label:const Text('اطلب هذه الخدمة'))]))); }

class OrderFormPage extends StatefulWidget { final String? service; const OrderFormPage({super.key,this.service}); @override State<OrderFormPage> createState()=>_OrderFormPageState(); }
class _OrderFormPageState extends State<OrderFormPage>{final form=GlobalKey<FormState>();final name=TextEditingController();final phone=TextEditingController();final details=TextEditingController();String? service;String colors='';String notes='';@override void initState(){super.initState();service=widget.service;}@override void dispose(){name.dispose();phone.dispose();details.dispose();super.dispose();}
Future<void> submit()async{if(!form.currentState!.validate())return;final client=supabaseClientOrNull;if(client==null){_show('لم يتم ربط قاعدة البيانات بعد. يرجى إعداد Supabase أولاً.');return;}try{final user=client.auth.currentUser;if(user==null){_show('سجّل الدخول أولاً حتى يرتبط الطلب بحسابك.');return;}final row=await client.from('orders').insert({'customer_id':user.id,'customer_name':name.text.trim(),'phone':phone.text.trim(),'service_title':service,'details':details.text.trim(),'color_preferences':colors,'notes':notes,'status':'received'}).select('order_number').single();_show('تم إرسال طلبك. رقم الطلب: ${row['order_number']}');if(mounted)Navigator.pop(context);}catch(e){_show('تعذر إرسال الطلب: $e');}}
void _show(String s)=>ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(s)));
@override Widget build(BuildContext context)=>Directionality(textDirection:TextDirection.rtl,child:Scaffold(appBar:AppBar(title:const Text('طلب خدمة')),body:Form(key:form,child:ListView(padding:const EdgeInsets.all(18),children:[const Text('تفاصيل طلبك',style:TextStyle(fontSize:24,fontWeight:FontWeight.bold)),const SizedBox(height:18),_field(name,'الاسم',required:true),_field(phone,'رقم الهاتف',required:true,keyboard:TextInputType.phone),DropdownButtonFormField<String>(value:service,decoration:const InputDecoration(labelText:'نوع الخدمة',filled:true),items:serviceItems.map((s)=>s.title).toSet().map((s)=>DropdownMenuItem(value:s,child:Text(s))).toList(),onChanged:(v)=>setState(()=>service=v),validator:(v)=>v==null?'اختر الخدمة':null),const SizedBox(height:12),_field(details,'وصف الطلب بالتفصيل',required:true,max:5),_field(TextEditingController(text:colors),'الألوان والتفضيلات'),_field(TextEditingController(text:notes),'ملاحظات إضافية',max:3),const SizedBox(height:10),const Text('إرفاق الصور والملفات: يتطلب تفعيل مساحة التخزين السحابية وربط صلاحيات الرفع قبل تشغيل هذه الميزة.',style:TextStyle(color:Colors.orangeAccent,fontSize:11)),const SizedBox(height:18),FilledButton.icon(onPressed:submit,icon:const Icon(Icons.send),label:const Text('إرسال الطلب'))]))));}
Widget _field(TextEditingController c,String label,{bool required=false,TextInputType? keyboard,int max=1})=>Padding(padding:const EdgeInsets.only(bottom:12),child:TextFormField(controller:c,keyboardType:keyboard,maxLines:max,decoration:InputDecoration(labelText:label,filled:true),validator:required?(v)=>(v==null||v.trim().isEmpty)?'هذا الحقل مطلوب':null:null));}

class OrdersPage extends StatelessWidget {const OrdersPage({super.key});@override Widget build(BuildContext context){final client=supabaseClientOrNull;return Directionality(textDirection:TextDirection.rtl,child:Scaffold(body:client==null?const Center(child:Text('تظهر طلباتك هنا بعد ربط قاعدة البيانات وتسجيل الدخول.')):FutureBuilder(future:client.from('orders').select().order('created_at',ascending:false),builder:(c,s){if(s.connectionState==ConnectionState.waiting)return const Center(child:CircularProgressIndicator());if(s.hasError)return Center(child:Text('تعذر تحميل الطلبات: ${s.error}'));final rows=(s.data as List);if(rows.isEmpty)return const Center(child:Text('لا توجد طلبات حتى الآن.'));return ListView(padding:const EdgeInsets.all(16),children:rows.map((r)=>Card(child:ListTile(title:Text('${r['service_title']??'طلب خدمة'}'),subtitle:Text('رقم الطلب: ${r['order_number']}\nالحالة: ${statusLabel(r['status'])}'),isThreeLine:true,leading:const Icon(Icons.receipt_long,color:aipCyan)))).toList();})));}}
String statusLabel(String? s)=>({'received':'تم استلام الطلب','review':'قيد المراجعة','in_progress':'جاري التنفيذ','client_approval':'بانتظار موافقة العميل','completed':'اكتمل التنفيذ','delivered':'تم التسليم','rejected':'مرفوض'}[s]??'غير محدد');

class AccountPage extends StatefulWidget{const AccountPage({super.key});@override State<AccountPage> createState()=>_AccountPageState();}
class _AccountPageState extends State<AccountPage>{final email=TextEditingController();final pass=TextEditingController();bool signup=false;@override Widget build(BuildContext context){final client=supabaseClientOrNull;return Directionality(textDirection:TextDirection.rtl,child:Scaffold(body:client==null?const Center(child:Padding(padding:EdgeInsets.all(24),child:Text('يلزم إعداد مشروع Supabase لتفعيل الحسابات وتسجيل الدخول.',textAlign:TextAlign.center))):StreamBuilder<AuthState>(stream:client.auth.onAuthStateChange,builder:(c,s){final user=client.auth.currentUser;if(user!=null)return Center(child:Column(mainAxisSize:MainAxisSize.min,children:[const Icon(Icons.verified_user,color:aipCyan,size:55),const SizedBox(height:12),Text(user.email??'حساب العميل'),const SizedBox(height:16),FilledButton.tonal(onPressed:()=>client.auth.signOut(),child:const Text('تسجيل الخروج'))]));return ListView(padding:const EdgeInsets.all(22),children:[const Text('حساب العميل',style:TextStyle(fontSize:25,fontWeight:FontWeight.bold)),const SizedBox(height:8),const Text('أنشئ حساباً لمتابعة طلباتك واستلام تحديثاتها.'),const SizedBox(height:18),TextField(controller:email,decoration:const InputDecoration(labelText:'البريد الإلكتروني')),const SizedBox(height:12),TextField(controller:pass,obscureText:true,decoration:const InputDecoration(labelText:'كلمة المرور')),const SizedBox(height:16),FilledButton(onPressed:()async{try{if(signup){await client.auth.signUp(email:email.text.trim(),password:pass.text);}else{await client.auth.signInWithPassword(email:email.text.trim(),password:pass.text);}if(mounted)setState((){});}catch(e){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('تعذر إكمال العملية: $e')));}},child:Text(signup?'إنشاء حساب':'تسجيل الدخول')),TextButton(onPressed:()=>setState(()=>signup=!signup),child:Text(signup?'لديك حساب؟ سجّل الدخول':'إنشاء حساب جديد'))];})));}}

SupabaseClient? get supabaseClientOrNull { try { return Supabase.instance.client; } catch (_) { return null; } }
