-- AIP backend schema for Supabase PostgreSQL.
-- Run in Supabase SQL Editor after creating the project.
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  phone text,
  role text not null default 'customer' check (role in ('customer','admin')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);


create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public
as $$ begin
  insert into public.profiles (id, full_name, phone)
  values (new.id, coalesce(new.raw_user_meta_data->>'full_name',''), coalesce(new.raw_user_meta_data->>'phone',''))
  on conflict (id) do nothing;
  return new;
end; $$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
for each row execute procedure public.handle_new_user();

create table if not exists public.services (
  id uuid primary key default gen_random_uuid(),
  category text not null,
  title text not null,
  short_description text not null default '',
  full_description text not null default '',
  image_url text,
  is_active boolean not null default true,
  sort_order int not null default 0,
  price numeric(12,2),
  created_at timestamptz not null default now()
);

create table if not exists public.orders (
  id uuid primary key default gen_random_uuid(),
  order_number bigint generated always as identity unique,
  customer_id uuid not null references auth.users(id) on delete cascade,
  customer_name text not null,
  phone text not null,
  service_title text not null,
  details text not null,
  color_preferences text,
  notes text,
  status text not null default 'received' check (status in ('received','review','in_progress','client_approval','completed','delivered','rejected')),
  admin_note text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.order_files (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references public.orders(id) on delete cascade,
  owner_id uuid not null references auth.users(id) on delete cascade,
  storage_path text not null,
  original_name text not null,
  mime_type text,
  file_role text not null default 'customer_upload' check (file_role in ('customer_upload','final_delivery')),
  created_at timestamptz not null default now()
);

create table if not exists public.portfolio_items (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  category text not null,
  description text,
  media_url text not null,
  media_type text not null default 'image' check (media_type in ('image','video')),
  is_published boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.offers (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  description text not null,
  starts_at timestamptz,
  ends_at timestamptz,
  is_active boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.notifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete cascade,
  title text not null,
  body text not null,
  data jsonb not null default '{}'::jsonb,
  read_at timestamptz,
  created_at timestamptz not null default now()
);

create or replace function public.is_admin()
returns boolean language sql stable security definer set search_path = public
as $$ select exists(select 1 from public.profiles p where p.id = auth.uid() and p.role = 'admin'); $$;

alter table public.profiles enable row level security;
alter table public.services enable row level security;
alter table public.orders enable row level security;
alter table public.order_files enable row level security;
alter table public.portfolio_items enable row level security;
alter table public.offers enable row level security;
alter table public.notifications enable row level security;

create policy "profile owner reads own profile" on public.profiles for select to authenticated using (id = auth.uid() or public.is_admin());
create policy "profile owner updates own profile" on public.profiles for update to authenticated using (id = auth.uid() and role = 'customer') with check (id = auth.uid() and role = 'customer');
create policy "admin manages profiles" on public.profiles for all to authenticated using (public.is_admin()) with check (public.is_admin());
create policy "public reads active services" on public.services for select using (is_active or public.is_admin());
create policy "admin manages services" on public.services for all to authenticated using (public.is_admin()) with check (public.is_admin());
create policy "customer creates own orders" on public.orders for insert to authenticated with check (customer_id = auth.uid());
create policy "customer reads own orders" on public.orders for select to authenticated using (customer_id = auth.uid() or public.is_admin());
create policy "admin updates orders" on public.orders for update to authenticated using (public.is_admin()) with check (public.is_admin());
create policy "customer sees own order files" on public.order_files for select to authenticated using (owner_id = auth.uid() or public.is_admin());
create policy "customer adds own order files" on public.order_files for insert to authenticated with check (owner_id = auth.uid());
create policy "admin manages order files" on public.order_files for all to authenticated using (public.is_admin()) with check (public.is_admin());
create policy "public reads published portfolio" on public.portfolio_items for select using (is_published or public.is_admin());
create policy "admin manages portfolio" on public.portfolio_items for all to authenticated using (public.is_admin()) with check (public.is_admin());
create policy "public reads active offers" on public.offers for select using (is_active or public.is_admin());
create policy "admin manages offers" on public.offers for all to authenticated using (public.is_admin()) with check (public.is_admin());
create policy "users read own notifications" on public.notifications for select to authenticated using (user_id = auth.uid() or public.is_admin());
create policy "users mark own notifications read" on public.notifications for update to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());
create policy "admin creates notifications" on public.notifications for insert to authenticated with check (public.is_admin());

-- Create a private Storage bucket named aip-private in the Supabase dashboard.
-- Storage policies must be configured separately; do not make customer uploads public.
